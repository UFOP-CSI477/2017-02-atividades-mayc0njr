<?php

namespace Model;

class Aluno {

}
