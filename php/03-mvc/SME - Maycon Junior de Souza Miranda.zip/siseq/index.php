<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Sistema de Manutencao de Equipamentos</title>
  </head>
  <body>

      <!-- Links //-->
      <a href="router.php?page=registros">Área Geral</a>
      <br>
      <a href="router.php?page=admin">Área Administrativa.</a>
  </body>
</html>
